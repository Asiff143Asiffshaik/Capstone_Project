
Predict Area of Forest burnt due to Forestfire:
The dataset used consists of 517 instances with 13 attributes in which 12 features and 1 target variable. This dataset is used to predict area of forest burnt due to Forestfire.
The predictive algorithms used in this project are KNeighborRegressor, RandomForestRegressor and DecisionTreeRegressor.
The task is made possible thanks to Python, and especially Scikit-Learn/Pandas libraries. Indeed, I used Anaconda3 for “all-in-one” installation.
In Python for Data Science , matrixplot This library is used to make Feature Scatter plot. ,NumPy:It provides some advance math functionalities to python.
The algorithm's performance is compared using pd.plotting.scatter_matrix.

Software Environment:
Anaconda3 v4.0.0 64bit (Python v3.5.2)
PyCharm 2016.1.3
IPython Notebook

Reference:
Forest Fire Dataset
Source: https://archive.ics.uci.edu/ml/datasets/forest+fires
